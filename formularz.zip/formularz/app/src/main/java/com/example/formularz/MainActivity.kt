package com.example.formularz
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editText1: EditText
    private lateinit var editText2: EditText
    private lateinit var editText3: EditText
    private lateinit var editText4: EditText
    private lateinit var buttonSubmit: Button
    private lateinit var resultTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText1 = findViewById(R.id.editText1)
        editText2 = findViewById(R.id.editText2)
        editText3 = findViewById(R.id.editText3)
        editText4 = findViewById(R.id.editText4)
        buttonSubmit = findViewById(R.id.buttonSubmit)
        resultTextView = findViewById(R.id.resultTextView)

        buttonSubmit.setOnClickListener {
            handleSubmitClick(it)
        }
    }

    private fun handleSubmitClick(view: View) {
        val text1 = editText1.text.toString()
        val text2 = editText2.text.toString()
        val text3 = editText3.text.toString()
        val text4 = editText4.text.toString()

        val message = "Wprowadzone dane:\n imie: $text1\n nazwisko: $text2\n data urodzenie: $text3\n nr telefonu: $text4"
    if (text1=="")        {
            resultTextView.text="wprowadź imię"
        }
        else if (text2.isEmpty() || ('@' !in text2 || '.' !in text2))
        {
            resultTextView.text="wprowadź poprawny adres email"
        }
    else if (text3.isEmpty() || text3.length<=8)
    {
        resultTextView.text="Hasło musi mieć 8 znaków"
    }
    else if (text4.isEmpty() || text4.length!=9)
    {
        resultTextView.text="wprowadź numer telefonu"
    }
        else
        {
            resultTextView.text = message
        }


    }
}
